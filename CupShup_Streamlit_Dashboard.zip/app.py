import io
from datetime import datetime, date
import pandas as pd
import streamlit as st
import plotly.express as px
import openpyxl

st.set_page_config(page_title="CupShup | BD Command Centre", page_icon="📊", layout="wide")

# CupShup palette
CHARCOAL = "#1D2121"
GREEN = "#00A979"
CYAN = "#0DA5E1"

st.markdown(f"""
<style>
    .stApp {{ background: #f5f7f7; }}
    [data-testid="stSidebar"] {{ background: {CHARCOAL}; }}
    [data-testid="stSidebar"] * {{ color: white !important; }}
    h1,h2,h3 {{ color: {CHARCOAL}; }}
    div[data-testid="stMetric"] {{
        background: white; border: 1px solid #e5eaea; border-radius: 12px;
        padding: 14px 16px; box-shadow: 0 1px 3px rgba(0,0,0,.04);
    }}
    .hero {{ background:{CHARCOAL}; color:white; padding:22px 26px; border-radius:14px; margin-bottom:16px; }}
    .hero h1 {{ color:white; margin:0; }}
    .hero p {{ color:#d8e2df; margin:6px 0 0 0; }}
    .note {{ background:#eef7f4; border-left:4px solid {GREEN}; padding:10px 14px; border-radius:6px; }}
    .warn {{ background:#fff7e8; border-left:4px solid #e6a23c; padding:10px 14px; border-radius:6px; }}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="hero">
  <h1>CupShup BD Command Centre</h1>
  <p>Leadership visibility across revenue, pipeline, outbound execution, team performance and all workbook sheets.</p>
</div>
""", unsafe_allow_html=True)

st.sidebar.title("CupShup BD")
st.sidebar.caption("Upload the latest Leadership Review workbook to refresh the dashboard.")
uploaded = st.sidebar.file_uploader("Upload Excel workbook (.xlsx)", type=["xlsx"])

if uploaded is None:
    st.info("Upload the original CupShup BD Pipeline Review workbook to load the dashboard. All worksheets will be retained in the Sheet Explorer.")
    st.markdown("**Workbook expected:** `CupShup_BD_Pipeline_Review.xlsx`")
    st.stop()

file_bytes = uploaded.getvalue()
try:
    wb_formula = openpyxl.load_workbook(io.BytesIO(file_bytes), data_only=False, read_only=True)
    wb_values = openpyxl.load_workbook(io.BytesIO(file_bytes), data_only=True, read_only=True)
except Exception as e:
    st.error(f"Could not open this workbook: {e}")
    st.stop()

sheet_names = wb_formula.sheetnames
st.sidebar.success(f"Loaded {len(sheet_names)} worksheets")
if len(sheet_names) != 22:
    st.sidebar.warning(f"This file has {len(sheet_names)} sheets. The original reviewed workbook had 22.")

def rows_to_df(ws, header_row=1, start_row=None):
    """Read worksheet rows with an explicitly selected header row (1-indexed)."""
    if start_row is None:
        start_row = header_row + 1
    values = list(ws.iter_rows(min_row=header_row, max_row=ws.max_row, values_only=True))
    if not values:
        return pd.DataFrame()
    headers = list(values[0])
    # Make blank/duplicate headers safe without changing their visible meaning.
    seen = {}
    cols = []
    for i, h in enumerate(headers):
        name = str(h).strip() if h is not None else f"Column {i+1}"
        if name in seen:
            seen[name] += 1
            name = f"{name}_{seen[name]}"
        else:
            seen[name] = 1
        cols.append(name)
    body = [list(r) for r in values[1:]]
    df = pd.DataFrame(body, columns=cols)
    # Drop completely empty rows and columns, retaining all actual source fields.
    df = df.dropna(how="all").dropna(axis=1, how="all")
    return df

def nonempty_df(ws):
    """Display-oriented full sheet view, preserving original rows and formulas."""
    vals = list(ws.iter_rows(values_only=True))
    if not vals:
        return pd.DataFrame()
    width = max((len(r) for r in vals), default=0)
    vals = [list(r) + [None] * (width-len(r)) for r in vals]
    df = pd.DataFrame(vals, columns=[f"Column {i+1}" for i in range(width)])
    # Convert uncommon openpyxl formula objects into readable text for Streamlit.
    for col in df.columns:
        df[col] = df[col].map(lambda v: str(v) if v is not None and not isinstance(v, (str, int, float, bool, datetime, date)) else v)
    return df.dropna(how="all").dropna(axis=1, how="all")

def clean_numeric(s):
    return pd.to_numeric(s, errors="coerce").fillna(0)

# Explicit source tables: row 4 headers in these sheets; LMS Raw and Daily Changes have row 1 headers.
tables = {}
for name in sheet_names:
    ws = wb_values[name]
    header = 1 if name in ["LMS Raw", "Daily Changes"] else 4
    if name in ["BD Log", "Targets", "Named Pipeline", "Outbound Meetings", "Realised Revenue", "Scoreboard Feed", "LMS Raw", "Daily Changes"]:
        tables[name] = rows_to_df(ws, header_row=header)

# Reusable data frames
bd = tables.get("BD Log", pd.DataFrame()).copy()
targets = tables.get("Targets", pd.DataFrame()).copy()
pipeline = tables.get("Named Pipeline", pd.DataFrame()).copy()
realised = tables.get("Realised Revenue", pd.DataFrame()).copy()
lms = tables.get("LMS Raw", pd.DataFrame()).copy()
scoreboard = tables.get("Scoreboard Feed", pd.DataFrame()).copy()
outbound = tables.get("Outbound Meetings", pd.DataFrame()).copy()

# Normalize date and numeric fields
if not bd.empty and "Date" in bd:
    bd["Date"] = pd.to_datetime(bd["Date"], errors="coerce")
if not bd.empty and "Month" in bd:
    bd["Month"] = pd.to_datetime(bd["Month"], errors="coerce")
for c in ["Inbound leads","Outbound reach-outs","Meetings done","Proposals sent","Proposal value (L)","Closed (L)","Week projection (L)","Month projection (L)"]:
    if c in bd: bd[c] = clean_numeric(bd[c])
if not targets.empty:
    for c in ["Q3 target","Oct target","Nov target","Dec target"]:
        if c in targets: targets[c] = clean_numeric(targets[c])
if not pipeline.empty:
    for c in ["Pipeline value (L)","Value in LMS (L)"]:
        if c in pipeline: pipeline[c] = clean_numeric(pipeline[c])
if not lms.empty and "Deal Value" in lms:
    lms["Deal Value"] = pd.to_numeric(lms["Deal Value"], errors="coerce")
if not scoreboard.empty:
    for c in ["Calls","Follow-up calls","Emails","Follow-up emails","LinkedIn","Meetings set"]:
        if c in scoreboard: scoreboard[c] = clean_numeric(scoreboard[c])
if not outbound.empty:
    for c in ["Emails (incl follow-up)","Calls (incl follow-up)","LinkedIn","Touches","Meetings set","Target","Gap"]:
        if c in outbound: outbound[c] = clean_numeric(outbound[c])

# Filters
st.sidebar.divider()
people = sorted(set(
    (bd["Person"].dropna().astype(str).tolist() if "Person" in bd else []) +
    (targets["Person"].dropna().astype(str).tolist() if "Person" in targets else [])
))
selected_people = st.sidebar.multiselect("BD team member", people, default=people)
months = []
if not bd.empty and "Month" in bd:
    months = sorted(bd["Month"].dropna().dt.strftime("%Y-%m").unique().tolist())
selected_months = st.sidebar.multiselect("Month (BD Log)", months, default=months)
person_filter = selected_people if selected_people else people

bd_f = bd.copy()
if not bd_f.empty:
    if "Person" in bd_f: bd_f = bd_f[bd_f["Person"].astype(str).isin(person_filter)]
    if selected_months and "Month" in bd_f:
        bd_f = bd_f[bd_f["Month"].dt.strftime("%Y-%m").isin(selected_months)]

# Top-level navigation
overview, performance, pipeline_tab, activity_tab, lms_tab, explorer, quality = st.tabs([
    "Executive Overview", "Team Performance", "Pipeline", "Outbound Activity", "LMS Health", "All 22 Sheets", "Data Quality"
])

with overview:
    st.subheader("Executive overview")
    st.caption("Revenue definitions are kept separate: BD closed revenue is signed agreement / advance / PO; realised revenue is delivered or billed revenue.")
    closed = float(bd_f["Closed (L)"].sum()) if "Closed (L)" in bd_f else 0.0
    q3_target = float(targets["Q3 target"].sum()) if "Q3 target" in targets else 0.0
    achieved = (closed / q3_target * 100) if q3_target else 0
    q3_billed = float(pd.to_numeric(realised.get("Q3 (L)", pd.Series(dtype=float)), errors="coerce").fillna(0).sum()) if not realised.empty else 0
    proposal_value = float(bd_f["Proposal value (L)"].sum()) if "Proposal value (L)" in bd_f else 0
    meetings = float(bd_f["Meetings done"].sum()) if "Meetings done" in bd_f else 0
    inbound = float(bd_f["Inbound leads"].sum()) if "Inbound leads" in bd_f else 0
    outbound_reach = float(bd_f["Outbound reach-outs"].sum()) if "Outbound reach-outs" in bd_f else 0

    c1,c2,c3,c4 = st.columns(4)
    c1.metric("BD closed", f"₹{closed:,.1f} L")
    c2.metric("Q3 target", f"₹{q3_target:,.1f} L")
    c3.metric("Target achievement", f"{achieved:.1f}%")
    c4.metric("Realised Q3 revenue", f"₹{q3_billed:,.1f} L")
    c5,c6,c7,c8 = st.columns(4)
    c5.metric("Proposal value logged", f"₹{proposal_value:,.1f} L")
    c6.metric("Meetings done", f"{meetings:,.0f}")
    c7.metric("Inbound leads", f"{inbound:,.0f}")
    c8.metric("Outbound reach-outs", f"{outbound_reach:,.0f}")

    if not bd_f.empty and {"Person","Closed (L)"}.issubset(bd_f.columns):
        by_rep = bd_f.groupby("Person", as_index=False)["Closed (L)"].sum().rename(columns={"Closed (L)":"Closed (L)"})
        fig = px.bar(by_rep.sort_values("Closed (L)", ascending=False), x="Person", y="Closed (L)", title="BD closed revenue by person (₹ Lakh)", text_auto=".1f")
        fig.update_layout(showlegend=False, plot_bgcolor="white", paper_bgcolor="white")
        st.plotly_chart(fig, use_container_width=True)
    if not bd_f.empty and {"Month","Closed (L)"}.issubset(bd_f.columns):
        monthly = bd_f.groupby(bd_f["Month"].dt.strftime("%Y-%m"), as_index=False)["Closed (L)"].sum()
        monthly.columns = ["Month","Closed (L)"]
        fig = px.line(monthly, x="Month", y="Closed (L)", markers=True, title="Monthly BD closures (₹ Lakh)")
        fig.update_layout(plot_bgcolor="white", paper_bgcolor="white")
        st.plotly_chart(fig, use_container_width=True)

    st.markdown('<div class="warn"><b>Source caveat:</b> Named Pipeline is explicitly labelled as a 2 Nov 2026 snapshot. Treat it as a dated pipeline snapshot until refreshed. Realised Revenue notes that Elixiir Q3 billing of ₹24.6 L is not credited in Shweta’s tab.</div>', unsafe_allow_html=True)

with performance:
    st.subheader("Team performance")
    if not targets.empty and not bd.empty and "Person" in targets and "Person" in bd:
        closed_rep = bd_f.groupby("Person", as_index=False)["Closed (L)"].sum() if "Closed (L)" in bd_f else pd.DataFrame(columns=["Person","Closed (L)"])
        perf = targets[["Person","Q3 target"]].merge(closed_rep, on="Person", how="left").fillna({"Closed (L)":0})
        perf["Achievement %"] = (perf["Closed (L)"] / perf["Q3 target"].replace(0, pd.NA) * 100).fillna(0)
        perf["Gap (L)"] = (perf["Q3 target"] - perf["Closed (L)"]).clip(lower=0)
        perf = perf[perf["Person"].astype(str).isin(person_filter)]
        st.dataframe(perf.sort_values("Achievement %", ascending=False), use_container_width=True, hide_index=True)
        fig = px.bar(perf, x="Person", y="Achievement %", color="Person", title="Q3 target achievement by person (%)", text_auto=".1f")
        fig.update_layout(showlegend=False, plot_bgcolor="white", paper_bgcolor="white")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.warning("The workbook does not contain the expected Targets and BD Log structure.")
    if not bd_f.empty:
        cols = [c for c in ["Date","Person","Inbound leads","Outbound reach-outs","Meetings done","Proposals sent","Proposal value (L)","Closed (L)","Closed brands"] if c in bd_f.columns]
        st.markdown("**Underlying BD Log records**")
        st.dataframe(bd_f[cols].sort_values("Date", ascending=False), use_container_width=True, hide_index=True)

with pipeline_tab:
    st.subheader("Named pipeline")
    st.markdown('<div class="warn">The Named Pipeline worksheet describes itself as a 2 Nov 2026 snapshot. It is shown as supplied and is not represented as a live CRM pipeline.</div>', unsafe_allow_html=True)
    if not pipeline.empty:
        pf = pipeline.copy()
        if "Person" in pf: pf = pf[pf["Person"].astype(str).isin(person_filter)]
        display_cols = [c for c in ["Person","Brand","Pipeline value (L)","LMS stage","Value in LMS (L)","Expected close month","Next step / note"] if c in pf.columns]
        if "LMS stage" in pf.columns and "Pipeline value (L)" in pf.columns:
            stage = pf.groupby("LMS stage", dropna=False, as_index=False).agg(Deals=("Brand","count"), **{"Pipeline value (L)":("Pipeline value (L)","sum")})
            st.dataframe(stage, use_container_width=True, hide_index=True)
            fig = px.bar(stage, x="LMS stage", y="Pipeline value (L)", title="Named pipeline by LMS stage (₹ Lakh)", text_auto=".1f")
            st.plotly_chart(fig, use_container_width=True)
        st.dataframe(pf[display_cols], use_container_width=True, hide_index=True)
    else:
        st.info("Named Pipeline sheet not found or has no readable records.")

with activity_tab:
    st.subheader("Outbound activity")
    if not scoreboard.empty and {"Person","Week start"}.issubset(scoreboard.columns):
        sf = scoreboard[scoreboard["Person"].astype(str).isin(person_filter)].copy()
        for c in ["Calls","Follow-up calls","Emails","Follow-up emails","LinkedIn","Meetings set"]:
            if c not in sf: sf[c] = 0
        sf["Total calls"] = sf["Calls"] + sf["Follow-up calls"]
        sf["Total emails"] = sf["Emails"] + sf["Follow-up emails"]
        sf["Total touches"] = sf["Total calls"] + sf["Total emails"] + sf["LinkedIn"]
        a,b,c,d = st.columns(4)
        a.metric("Calls incl. follow-up", f"{sf['Total calls'].sum():,.0f}")
        b.metric("Emails incl. follow-up", f"{sf['Total emails'].sum():,.0f}")
        c.metric("LinkedIn messages", f"{sf['LinkedIn'].sum():,.0f}")
        d.metric("Meetings set", f"{sf['Meetings set'].sum():,.0f}")
        if not sf.empty:
            chart = sf.groupby("Person", as_index=False)[["Total calls","Total emails","LinkedIn","Meetings set"]].sum()
            long = chart.melt("Person", var_name="Activity", value_name="Count")
            fig = px.bar(long, x="Person", y="Count", color="Activity", barmode="group", title="Activity by person")
            st.plotly_chart(fig, use_container_width=True)
        st.dataframe(sf, use_container_width=True, hide_index=True)
    else:
        st.info("Scoreboard Feed not found or has no readable records.")
    if not outbound.empty:
        st.markdown("**Outbound meetings by rep and week**")
        outf = outbound[outbound["Rep"].astype(str).isin(person_filter)] if "Rep" in outbound else outbound
        st.dataframe(outf, use_container_width=True, hide_index=True)

with lms_tab:
    st.subheader("LMS overview")
    if not lms.empty:
        lf = lms.copy()
        if "Assigned To Name" in lf:
            rep_short = {"Shweta":"Shweta","Oshima":"Oshima Garg","Tashu":"Tashu Jaiswal","Sanchi":"Sanchi Tayal"}
            allowed_names = [rep_short.get(x,x) for x in person_filter]
            lf = lf[lf["Assigned To Name"].astype(str).isin(allowed_names)]
        stage_col = "Stage" if "Stage" in lf else None
        rep_col = "Assigned To Name" if "Assigned To Name" in lf else None
        x1,x2,x3 = st.columns(3)
        x1.metric("LMS records in view", f"{len(lf):,}")
        x2.metric("Records with deal value", f"{lf['Deal Value'].notna().sum():,}" if "Deal Value" in lf else "—")
        x3.metric("Unassigned records", f"{lf['Assigned To Name'].isna().sum():,}" if "Assigned To Name" in lf else "—")
        if stage_col:
            st.markdown("**Lead count by stage**")
            st.dataframe(lf[stage_col].fillna("Blank").value_counts().rename_axis("Stage").reset_index(name="Leads"), use_container_width=True, hide_index=True)
        if rep_col:
            st.markdown("**Lead count by assigned owner**")
            st.dataframe(lf[rep_col].fillna("Unassigned").value_counts().rename_axis("Assigned To Name").reset_index(name="Leads"), use_container_width=True, hide_index=True)
        cols = [c for c in ["Name","Brand Name","Source","Stage","Assigned To Name","Deal Value","Next Follow Up","Next Action","Next Action Date","Expected Close Date","Created At"] if c in lf.columns]
        st.markdown("**LMS records**")
        st.dataframe(lf[cols], use_container_width=True, hide_index=True)
    else:
        st.warning("LMS Raw sheet not found.")

with explorer:
    st.subheader("All worksheets — full source explorer")
    st.caption("Every worksheet in the uploaded workbook is available below. Formula cells are shown as stored in the workbook; formulas are not recalculated by this app.")
    chosen_sheet = st.selectbox("Choose a worksheet", sheet_names)
    ws = wb_formula[chosen_sheet]
    # Keep sheet rows intact, including title/notes and supporting columns.
    raw_df = nonempty_df(ws)
    st.write(f"**{chosen_sheet}** · {ws.max_row:,} rows × {ws.max_column:,} columns · {len(raw_df):,} non-empty rows displayed")
    st.dataframe(raw_df, use_container_width=True, height=560, hide_index=True)
    csv = raw_df.to_csv(index=False).encode("utf-8-sig")
    st.download_button("Download this sheet as CSV", csv, file_name=f"{chosen_sheet.replace(' ','_')}.csv", mime="text/csv")

with quality:
    st.subheader("Workbook coverage and data quality")
    st.write(f"**Worksheets detected:** {len(sheet_names)}")
    sheet_meta = []
    for name in sheet_names:
        ws = wb_formula[name]
        nonempty_rows = 0
        for row in ws.iter_rows(values_only=True):
            if any(v is not None for v in row):
                nonempty_rows += 1
        formulas = 0
        for row in ws.iter_rows():
            formulas += sum(1 for cell in row if isinstance(cell.value, str) and cell.value.startswith("="))
        sheet_meta.append({"Worksheet":name,"Rows (used range)":ws.max_row,"Columns (used range)":ws.max_column,"Non-empty rows":nonempty_rows,"Formula cells":formulas})
    st.dataframe(pd.DataFrame(sheet_meta), use_container_width=True, hide_index=True)
    st.markdown("**Known source notes preserved from the workbook**")
    notes = []
    for name in sheet_names:
        ws = wb_values[name]
        for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row,3), values_only=True):
            for val in row:
                if isinstance(val,str) and len(val.strip()) > 50:
                    notes.append({"Sheet":name,"Source note":val.strip()})
                    break
            if notes and notes[-1]["Sheet"] == name: break
    if notes:
        st.dataframe(pd.DataFrame(notes), use_container_width=True, hide_index=True)
    st.markdown('<div class="warn"><b>Important:</b> This app reads the uploaded workbook snapshot. It does not connect to the private Google Sheet automatically. Upload a fresh Excel export whenever the source tracker changes. Formula cells are not recalculated in Python; operational KPIs are calculated from the raw source tables where possible.</div>', unsafe_allow_html=True)

st.sidebar.divider()
st.sidebar.caption("CupShup · Internal BD reporting · Workbook snapshot dashboard")
